import { menu } from './data.js';

function scrollMenu(direction) {
	const scrollInterval = setInterval(function () {}, 10);
}

function cutText(text) {}

function handleOpenModal(menuId) {
	setTimeout(function () {}, 600);
}
